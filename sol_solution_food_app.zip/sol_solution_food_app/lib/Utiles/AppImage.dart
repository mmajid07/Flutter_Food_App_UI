class AppImage {
  static const String welcomeImage1 = "asset/images/Welcome_Image1.png";
  static const String welcomeImage2 = "asset/images/Welcome_Image2.png";
  static const String ButtonImage = "asset/images/NextBTN.png";
  static const String Unb1_image1 = "asset/images/Unb1_Image1.png";
  static const String Unb1_image2 = "asset/images/Unb1_Image2.png";
  static const String Unb2_image = "asset/images/Unb2_Image.png";
  static const String Unb3_image = "asset/images/Unb3_Image.png";
  static const String bg_image = "asset/images/bg.png";
  static const String ic_Google = "asset/images/ic_google.png";
}
