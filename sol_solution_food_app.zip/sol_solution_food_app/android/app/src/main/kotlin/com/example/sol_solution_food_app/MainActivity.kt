package com.example.sol_solution_food_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
